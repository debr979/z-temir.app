#!/bin/sh
# Installs z-temir for the current user: ~/.local/bin, the app menu entry and
# its icon. Needs GTK 3 and WebKitGTK 4.1, e.g. on Debian/Ubuntu:
#   sudo apt install libgtk-3-0 libwebkit2gtk-4.1-0
set -e
cd "$(dirname "$0")"
install -Dm755 z-temir "$HOME/.local/bin/z-temir"
install -Dm644 z-temir.png "$HOME/.local/share/icons/hicolor/512x512/apps/z-temir.png"
install -Dm644 z-temir.desktop "$HOME/.local/share/applications/z-temir.desktop"
echo "Installed to ~/.local/bin/z-temir (make sure ~/.local/bin is on your PATH)."
